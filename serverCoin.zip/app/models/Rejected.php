<?php

class Rejected extends Eloquent  {

   protected $table = 'rejected';

}
