<?php

class Porcentaje extends Eloquent  {

   protected $table = 'porcentaje_general';

}
