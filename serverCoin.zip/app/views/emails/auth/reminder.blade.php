<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Restablecer Contraseña</h2>

		<div>
			Código: $codigo;
		</div>
	</body>
</html>
