<?php 

return array( 
	
	/*
	|--------------------------------------------------------------------------
	| Pusher Config
	|--------------------------------------------------------------------------
	|
	| Pusher is a simple hosted API for quickly, easily and securely adding
	| realtime bi-directional functionality via WebSockets to web and mobile 
	| apps, or any other Internet connected device.
	|
	*/

	/**
	 * App id
	 */
	'app_id' => '125866', 

	/**
	 * App key
	 */
	'key' => 'ce4fe4de32d6655ba234',

	/**
	 * App Secret
	 */
	'secret' => '54809d1a0eb6e9f08d87'	

);