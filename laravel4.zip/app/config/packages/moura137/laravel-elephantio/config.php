<?php

return array(
    
    'url'   => 'http://localhost/proyectos_laravel/laravel4/public/hola',
    //'url'   => 'http://localhost/',

    'port'  => '80',

    'debug' => true,
);