<?php

class Puerta extends Eloquent  {

   protected $table = 'estado_puerta';

}
