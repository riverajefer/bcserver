<?php

class UserPorcentaje extends Eloquent  {

   protected $table = 'users_porcentaje';



}
