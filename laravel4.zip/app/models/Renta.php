<?php

class Renta extends Eloquent  {

   protected $table = 'rentabilidad';

}
